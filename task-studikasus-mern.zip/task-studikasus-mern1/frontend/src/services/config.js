// src/services/config.js
export const API_URL = "http://localhost:8000/api";
